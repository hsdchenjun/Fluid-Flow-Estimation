
close all;
clear;

%*************************************************
%Please chose a fluid-like image sequence

%fluid_type ='Sink';       %Divergence motion
%fluid_type ='Vortex';     %Rotation motion
%fluid_type ='Poiseuille';
%fluid_type ='Lamb-Oseen';
%fluid_type ='particle';
fluid_type ='WO';         %Jupiter’s White Ovals
%fluid_type ='Typhoon';   %



if strcmp(fluid_type,'Sink')
fprintf(fluid_type);    
I10 = double(imread('data/a4b_10.tif'))/255;
I20 = double(imread('data/a4b_11.tif'))/255;
downsample = 4;
scale = 25;
end

if strcmp(fluid_type,'Vortex')
fprintf(fluid_type);    
I10 = double(imread('data/a5b_10.tif'))/255;
I20 = double(imread('data/a5b_11.tif'))/255;
downsample = 4;
scale = 40;
end

if strcmp(fluid_type,'Poiseuille')
fprintf(fluid_type);
I10 = double(imread('data/a1b_10.tif'))/255;
I20 = double(imread('data/a1b_11.tif'))/255;
downsample = 5;
scale = 12;
end

if strcmp(fluid_type,'Lamb-Oseen')
fprintf(fluid_type);    
I10 = double(imread('data/a2b_10.tif'))/255;
I20 = double(imread('data/a2b_11.tif'))/255;
downsample = 6;
scale = 12;
end

if strcmp(fluid_type,'particle')
I10 = double(imread('data/run010050410.tif'))/255;
I20 = double(imread('data/run010050420.tif'))/255;
downsample = 5;
scale = 12;
end

if strcmp(fluid_type,'WO')
I10 = double(imread('data/White_Oval_1.tif'))/255;
I20 = double(imread('data/White_Oval_2.tif'))/255;
downsample = 5;
scale = 20;
end

if strcmp(fluid_type,'Typhoon')
I10 = double(imread('data/typhoon3.png'))/255;
I20 = double(imread('data/typhoon4.png'))/255;
downsample = 5;
scale = 12;
end

[M,N,C] = size(I10);
if(C==1)
   I1 = zeros(M,N,3);
   I1(:,:,1)=I10;
   I1(:,:,2)=I10;
   I1(:,:,3)=I10;
   I2 = zeros(M,N,3);
   I2(:,:,1)=I20;
   I2(:,:,2)=I20;
   I2(:,:,3)=I20;
else
    I1=I10;
    I2=I20;
end

% parameter settings
 ps = parameter_settings();
 
 ps.lambda = 0.05;% the weight to control the number of the preserved non-zero flow graidents
 ps.alpha =0.5; % the weight of the regularization term
 ps.pyramid_factor = 0.5; % rescalling settings
 ps.warps = 5; % the numbers of warps per level
 ps.max_its = 5; % the number of equation iterations per warp

tic
[flow] = coarse_to_fine(I1, I2, ps);
toc
u = flow(:, :, 1);
v = flow(:, :, 2);


plots_set_2;
plots_set_1;



